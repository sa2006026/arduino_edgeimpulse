See notes in the various block folders in studio/dsp-pipeline

studio/dsp-pipeline/mfcc/README.md